"""
This module contains utilities for working with SHACL shapes graphs.
"""

from __future__ import annotations

from typing import Union

from rdflib import Graph, Literal, URIRef
from rdflib.namespace import RDF, SH
from rdflib.paths import AlternativePath, InvPath, MulPath, Path, SequencePath
from rdflib.term import Node


class SHACLPathError(Exception):
    """
    Raised when a node in a shapes graph is not a valid SHACL path.
    """


# The SHACL-to-SPARQL path conversion in pyshacl is the basis of this
# implementation.
def parse_shacl_path(
    shapes_graph: Graph,
    path_identifier: Node,
) -> Union[URIRef, Path]:
    """
    Convert the object of a ``sh:path`` triple into a path usable as a predicate.

    A valid SHACL path is either an IRI, which denotes a plain predicate, or a
    blank node that is an RDF list (a sequence path) or that carries one of the
    SHACL path predicates: ``sh:inversePath``, ``sh:alternativePath``,
    ``sh:zeroOrMorePath``, ``sh:oneOrMorePath`` or ``sh:zeroOrOnePath``.

    :param shapes_graph: the :class:`~rdflib.graph.Graph` holding the shapes.
        It is only read, never modified.
    :param path_identifier: the path node, that is the object of the
        ``sh:path`` triple. It must be a node of the shapes graph.
    :return: the :class:`~rdflib.term.URIRef` itself for a plain predicate,
        or a :class:`~rdflib.paths.Path` for a complex path.
    :raises TypeError: if ``path_identifier`` is a
        :class:`~rdflib.term.Literal`.
    :raises SHACLPathError: if the path is malformed or unrecognized.
    """
    if isinstance(path_identifier, Literal):
        raise TypeError("Literals are not valid SHACL paths")
    if not isinstance(path_identifier, Node):  # type: ignore[unreachable]
        raise SHACLPathError(
            f"Not a node, so not a valid SHACL path: {path_identifier!r}"
        )
    # A plain predicate.
    if isinstance(path_identifier, URIRef):
        if path_identifier == RDF.nil:
            raise SHACLPathError("rdf:nil is not a valid SHACL path")
        return path_identifier
    # A sequence path, written as an RDF list.
    if (path_identifier, RDF.first, None) in shapes_graph:
        items = list(shapes_graph.items(path_identifier))
        if len(items) < 2:
            raise SHACLPathError(
                f"A sequence path needs at least two items: {path_identifier!r}"
            )
        return SequencePath(*[parse_shacl_path(shapes_graph, item) for item in items])
    # sh:inversePath
    inverse = shapes_graph.value(path_identifier, SH.inversePath)
    if inverse is not None:
        return InvPath(parse_shacl_path(shapes_graph, inverse))
    # sh:alternativePath, whose value is an RDF list
    alternatives = shapes_graph.value(path_identifier, SH.alternativePath)
    if alternatives is not None:
        alternative_items = list(shapes_graph.items(alternatives))
        if len(alternative_items) < 2:
            raise SHACLPathError(
                f"An alternative path needs at least two items: {path_identifier!r}"
            )
        return AlternativePath(
            *[parse_shacl_path(shapes_graph, item) for item in alternative_items]
        )
    # sh:zeroOrMorePath
    zero_or_more = shapes_graph.value(path_identifier, SH.zeroOrMorePath)
    if zero_or_more is not None:
        return MulPath(parse_shacl_path(shapes_graph, zero_or_more), "*")
    # sh:oneOrMorePath
    one_or_more = shapes_graph.value(path_identifier, SH.oneOrMorePath)
    if one_or_more is not None:
        return MulPath(parse_shacl_path(shapes_graph, one_or_more), "+")
    # sh:zeroOrOnePath
    zero_or_one = shapes_graph.value(path_identifier, SH.zeroOrOnePath)
    if zero_or_one is not None:
        return MulPath(parse_shacl_path(shapes_graph, zero_or_one), "?")
    raise SHACLPathError(f"Unrecognized SHACL path node: {path_identifier!r}")
