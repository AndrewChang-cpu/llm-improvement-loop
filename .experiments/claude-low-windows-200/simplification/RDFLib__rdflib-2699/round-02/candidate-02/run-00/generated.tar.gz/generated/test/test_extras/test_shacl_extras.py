from __future__ import annotations

from typing import Set, Tuple, Type, Union

import pytest

from rdflib import Graph, URIRef
from rdflib.extras.shacl import SHACLPathError, parse_shacl_path
from rdflib.namespace import SH, Namespace
from rdflib.paths import Path

EX = Namespace("http://example.org/")

SHAPES_TTL = """
@prefix ex: <http://example.org/> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix sh: <http://www.w3.org/ns/shacl#> .

ex:iri sh:path ex:p1 .
ex:seq sh:path ( ex:p1 ex:p2 ex:p3 ) .
ex:nestedSeq sh:path ( ex:p1 ( ex:p2 ex:p3 ) ) .
ex:partialSeq sh:path [ rdf:first ex:p1 ; rdf:rest [ rdf:first ex:p2 ] ] .
ex:inv sh:path [ sh:inversePath ex:p1 ] .
ex:alt sh:path [ sh:alternativePath ( ex:p1 ex:p2 ex:p3 ) ] .
ex:nestedAlt sh:path [
    sh:alternativePath ( ( ex:p1 ex:p2 ) [ sh:inversePath ex:p3 ] ex:p4 )
] .
ex:zeroOrMore sh:path [ sh:zeroOrMorePath ex:p1 ] .
ex:oneOrMore sh:path [ sh:oneOrMorePath ex:p1 ] .
ex:zeroOrOne sh:path [ sh:zeroOrOnePath ex:p1 ] .
ex:modInv sh:path [ sh:zeroOrMorePath [ sh:inversePath ex:p1 ] ] .

ex:nilPath sh:path () .
ex:oneSeq sh:path ( ex:p1 ) .
ex:emptyAlt sh:path [ sh:alternativePath () ] .
ex:oneAlt sh:path [ sh:alternativePath ( ex:p1 ) ] .
ex:unknown sh:path [ ex:other ex:p1 ] .
ex:literal sh:path "not a path" .
"""

VALID_CASES: list[Tuple[str, Union[URIRef, Path]]] = [
    ("iri", EX.p1),
    ("seq", EX.p1 / EX.p2 / EX.p3),
    ("nestedSeq", EX.p1 / (EX.p2 / EX.p3)),
    ("partialSeq", EX.p1 / EX.p2),
    ("inv", ~EX.p1),
    ("alt", EX.p1 | EX.p2 | EX.p3),
    ("nestedAlt", (EX.p1 / EX.p2) | ~EX.p3 | EX.p4),
    ("zeroOrMore", EX.p1 * "*"),  # type: ignore[operator]
    ("oneOrMore", EX.p1 * "+"),  # type: ignore[operator]
    ("zeroOrOne", EX.p1 * "?"),  # type: ignore[operator]
    ("modInv", (~EX.p1) * "*"),
]

INVALID_CASES: list[Tuple[str, Type[Exception]]] = [
    ("nilPath", SHACLPathError),
    ("oneSeq", SHACLPathError),
    ("emptyAlt", SHACLPathError),
    ("oneAlt", SHACLPathError),
    ("unknown", SHACLPathError),
    ("literal", TypeError),
]


@pytest.fixture(scope="module")
def shapes_graph() -> Graph:
    graph = Graph()
    graph.parse(data=SHAPES_TTL, format="turtle")
    return graph


@pytest.mark.parametrize("shape, expected", VALID_CASES)
def test_parse_shacl_path(
    shapes_graph: Graph, shape: str, expected: Union[URIRef, Path]
) -> None:
    before: Set[object] = set(shapes_graph)
    path = shapes_graph.value(EX[shape], SH.path)
    assert parse_shacl_path(shapes_graph, path) == expected  # type: ignore[arg-type]
    assert set(shapes_graph) == before


@pytest.mark.parametrize("shape, exc_type", INVALID_CASES)
def test_parse_shacl_path_invalid(
    shapes_graph: Graph, shape: str, exc_type: Type[Exception]
) -> None:
    before: Set[object] = set(shapes_graph)
    path = shapes_graph.value(EX[shape], SH.path)
    with pytest.raises(exc_type):
        parse_shacl_path(shapes_graph, path)  # type: ignore[arg-type]
    assert set(shapes_graph) == before


@pytest.mark.parametrize("bad_input", [None, "http://example.org/p1"])
def test_parse_shacl_path_non_node_input(
    shapes_graph: Graph, bad_input: object
) -> None:
    before: Set[object] = set(shapes_graph)
    with pytest.raises(SHACLPathError):
        parse_shacl_path(shapes_graph, bad_input)  # type: ignore[arg-type]
    assert set(shapes_graph) == before
