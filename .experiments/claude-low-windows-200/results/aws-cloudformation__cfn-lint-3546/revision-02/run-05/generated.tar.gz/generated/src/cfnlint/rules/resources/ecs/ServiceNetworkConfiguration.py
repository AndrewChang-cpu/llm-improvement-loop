"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceNetworkConfiguration(CfnLintKeyword):
    id = "E3052"
    shortdesc = (
        "Validate ECS services with a task definition using awsvpc "
        "network mode have a NetworkConfiguration"
    )
    description = (
        "When an ECS service references a task definition with a NetworkMode "
        "of awsvpc the service has to specify a NetworkConfiguration"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _get_task_definition_name(self, value: Any) -> str | None:
        fn_k, fn_v = is_function(value)
        if fn_k == "Ref":
            if isinstance(fn_v, str):
                return fn_v
        elif fn_k == "Fn::GetAtt":
            values = ensure_list(fn_v)
            if values and isinstance(values[0], str):
                return values[0].split(".")[0]
        return None

    def validate(
        self, validator: Validator, keyword: str, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        for task_definition, task_definition_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._get_task_definition_name(task_definition)
            if name is None:
                continue
            for (
                network_configuration,
                network_configuration_validator,
            ) in get_value_from_path(
                task_definition_validator, instance, deque(["NetworkConfiguration"])
            ):
                resource, resource_validator = get_resource_by_name(
                    network_configuration_validator,
                    name,
                    ["AWS::ECS::TaskDefinition"],
                )
                if not resource:
                    continue
                for network_mode, _mode_validator in get_value_from_path(
                    resource_validator,
                    resource,
                    deque(["Properties", "NetworkMode"]),
                ):
                    if network_mode != "awsvpc":
                        continue
                    if network_configuration is None:
                        yield ValidationError(
                            "'NetworkConfiguration' is a required property",
                            validator="required",
                            rule=self,
                        )
