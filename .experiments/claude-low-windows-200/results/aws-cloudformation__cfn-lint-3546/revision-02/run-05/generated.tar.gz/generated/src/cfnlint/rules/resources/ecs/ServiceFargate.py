"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceFargate(CfnLintKeyword):
    id = "E3054"
    shortdesc = (
        "Validate ECS services using FARGATE reference a task definition "
        "that allows FARGATE"
    )
    description = (
        "When an ECS service has a LaunchType of FARGATE the task definition "
        "it references has to list FARGATE in its RequiresCompatibilities"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _get_task_definition_name(self, value: Any) -> str | None:
        fn_k, fn_v = is_function(value)
        if fn_k == "Ref":
            if isinstance(fn_v, str):
                return fn_v
        elif fn_k == "Fn::GetAtt":
            values = ensure_list(fn_v)
            if values and isinstance(values[0], str):
                return values[0].split(".")[0]
        return None

    def _is_fargate_compatible(self, value: Any) -> bool:
        return isinstance(value, dict) or value == "FARGATE"

    def validate(
        self, validator: Validator, keyword: str, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        for task_definition, task_definition_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._get_task_definition_name(task_definition)
            if name is None:
                continue
            for launch_type, launch_type_validator in get_value_from_path(
                task_definition_validator, instance, deque(["LaunchType"])
            ):
                if launch_type != "FARGATE":
                    continue
                resource, resource_validator = get_resource_by_name(
                    launch_type_validator,
                    name,
                    ["AWS::ECS::TaskDefinition"],
                )
                if not resource:
                    continue
                yield from self._validate_requires_compatibilities(
                    resource_validator, resource
                )

    def _validate_requires_compatibilities(
        self, validator: Validator, resource: Any
    ) -> ValidationResult:
        for compatibilities, compatibilities_validator in get_value_from_path(
            validator, resource, deque(["Properties", "RequiresCompatibilities"])
        ):
            if compatibilities is None:
                # Strip the last path segment so the override points at the
                # enclosing location (Properties, the resource, or the key itself
                # when the value is AWS::NoValue).
                path = deque(compatibilities_validator.context.path.path)
                path.pop()
                yield ValidationError(
                    "'RequiresCompatibilities' is a required property",
                    validator="required",
                    path_override=path,
                    rule=self,
                )
                continue

            if not isinstance(compatibilities, list):
                continue

            found = False
            for item, _ in get_value_from_path(
                compatibilities_validator,
                compatibilities,
                deque(["*"]),
            ):
                if self._is_fargate_compatible(item):
                    found = True
                    break
            if found:
                continue

            yield ValidationError(
                f"{compatibilities!r} does not contain items matching 'FARGATE'",
                validator="contains",
                path_override=compatibilities_validator.context.path.path,
                rule=self,
            )
