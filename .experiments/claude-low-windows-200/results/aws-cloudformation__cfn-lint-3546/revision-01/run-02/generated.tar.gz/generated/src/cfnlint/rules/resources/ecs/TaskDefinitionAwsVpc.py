"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


def _display(value: Any) -> str:
    if isinstance(value, str):
        return f"'{value}'"
    return str(value)


class TaskDefinitionAwsVpc(CfnLintKeyword):
    id = "E3053"
    shortdesc = "Validate ECS awsvpc tasks have matching host and container ports"
    description = (
        "When an ECS task definition has a 'NetworkMode' of 'awsvpc' the "
        "'HostPort' of each port mapping must equal its 'ContainerPort'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
        )

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        is_awsvpc = False
        for network_mode, _mode_validator in get_value_from_path(
            validator, instance, deque(["NetworkMode"])
        ):
            if network_mode == "awsvpc":
                is_awsvpc = True
        if not is_awsvpc:
            return

        for container, container_validator in get_value_from_path(
            validator,
            instance,
            deque(["ContainerDefinitions", "*"]),
        ):
            for mapping, mapping_validator in get_value_from_path(
                container_validator,
                container,
                deque(["PortMappings", "*"]),
            ):
                for host_port, host_validator in get_value_from_path(
                    mapping_validator, mapping, deque(["HostPort"])
                ):
                    if not isinstance(host_port, (str, int)):
                        continue
                    for container_port, _port_validator in get_value_from_path(
                        mapping_validator, mapping, deque(["ContainerPort"])
                    ):
                        if not isinstance(container_port, (str, int)):
                            continue
                        if str(host_port) == str(container_port):
                            continue
                        yield ValidationError(
                            f"{_display(host_port)} does not equal "
                            f"{_display(container_port)}",
                            validator="const",
                            path_override=host_validator.context.path.path,
                            rule=self,
                        )
