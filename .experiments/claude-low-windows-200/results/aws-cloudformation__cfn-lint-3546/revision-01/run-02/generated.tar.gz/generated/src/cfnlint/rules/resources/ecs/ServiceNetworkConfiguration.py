"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceNetworkConfiguration(CfnLintKeyword):
    id = "E3052"
    shortdesc = (
        "Validate ECS services have a NetworkConfiguration when the task "
        "definition uses awsvpc network mode"
    )
    description = (
        "When an ECS service references a task definition with a 'NetworkMode' "
        "of 'awsvpc' the service must define a 'NetworkConfiguration'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _resolve_name(self, instance: Any) -> str | None:
        fn_k, fn_v = is_function(instance)
        if fn_k == "Ref" and isinstance(fn_v, str):
            return fn_v
        if fn_k == "Fn::GetAtt":
            values = ensure_list(fn_v)
            if values and isinstance(values[0], str):
                return values[0].split(".")[0]
        return None

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[Any, Validator]]:
        for task_ref, task_ref_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._resolve_name(task_ref)
            if name is None:
                continue
            task_def, task_def_validator = get_resource_by_name(
                task_ref_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if not task_def:
                continue
            yield task_def, task_def_validator

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        for task_def, task_def_validator in self._get_task_definitions(
            validator, instance
        ):
            is_awsvpc = False
            for network_mode, _mode_validator in get_value_from_path(
                task_def_validator,
                task_def,
                deque(["Properties", "NetworkMode"]),
            ):
                if network_mode == "awsvpc":
                    is_awsvpc = True
            if not is_awsvpc:
                continue

            for network_config, _config_validator in get_value_from_path(
                validator,
                instance,
                deque(["NetworkConfiguration"]),
            ):
                if network_config is None:
                    yield ValidationError(
                        "'NetworkConfiguration' is a required property",
                        validator="required",
                        rule=self,
                    )
                    break
