"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceFargate(CfnLintKeyword):
    id = "E3054"
    shortdesc = (
        "Validate ECS services using FARGATE reference a task definition "
        "that allows FARGATE"
    )
    description = (
        "When an ECS service has a LaunchType of 'FARGATE' the task definition "
        "it references has to have 'FARGATE' in its RequiresCompatibilities"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _filter_resource_name(self, instance: Any) -> str | None:
        fn_k, fn_v = is_function(instance)
        if fn_k == "Ref":
            if isinstance(fn_v, str):
                return fn_v
        elif fn_k == "Fn::GetAtt":
            values = ensure_list(fn_v)
            if values and isinstance(values[0], str):
                return values[0].split(".")[0]
        return None

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[Any, Validator]]:
        for task_definition, task_definition_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._filter_resource_name(task_definition)
            if name is None:
                continue
            resource, resource_validator = get_resource_by_name(
                task_definition_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if not resource:
                continue
            yield resource, resource_validator

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        launch_types = [
            launch_type
            for launch_type, _lt_validator in get_value_from_path(
                validator, instance, deque(["LaunchType"])
            )
        ]
        if "FARGATE" not in launch_types:
            return

        for resource, resource_validator in self._get_task_definitions(
            validator, instance
        ):
            for properties, properties_validator in get_value_from_path(
                resource_validator, resource, deque(["Properties"])
            ):
                for compatibilities, compat_validator in get_value_from_path(
                    properties_validator,
                    properties,
                    deque(["RequiresCompatibilities"]),
                ):
                    if compatibilities is None:
                        yield ValidationError(
                            "'RequiresCompatibilities' is a required property",
                            validator="required",
                            path_override=properties_validator.context.path.path,
                            rule=self,
                        )
                        continue
                    if not isinstance(compatibilities, list):
                        continue
                    if any(
                        is_function(item)[0] is not None or item == "FARGATE"
                        for item in compatibilities
                    ):
                        continue
                    yield ValidationError(
                        f"{compatibilities!r} does not contain items "
                        "matching 'FARGATE'",
                        validator="contains",
                        path_override=compat_validator.context.path.path,
                        rule=self,
                    )
