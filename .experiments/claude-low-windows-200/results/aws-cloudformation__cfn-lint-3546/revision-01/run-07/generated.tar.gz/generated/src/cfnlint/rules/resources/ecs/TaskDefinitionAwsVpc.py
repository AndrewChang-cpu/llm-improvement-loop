"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class TaskDefinitionAwsVpc(CfnLintKeyword):
    id = "E3053"
    shortdesc = "Validate ECS awsvpc tasks have matching host and container ports"
    description = (
        "When the NetworkMode of an ECS task definition is 'awsvpc' "
        "the HostPort of each port mapping has to equal its ContainerPort"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
        )

    def _format(self, value: Any) -> str:
        return repr(value)

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        network_modes = [
            mode
            for mode, _mode_validator in get_value_from_path(
                validator, instance, deque(["NetworkMode"])
            )
        ]
        if "awsvpc" not in network_modes:
            return

        for container, container_validator in get_value_from_path(
            validator, instance, deque(["ContainerDefinitions", "*"])
        ):
            for port_mapping, port_mapping_validator in get_value_from_path(
                container_validator,
                container,
                deque(["PortMappings", "*"]),
            ):
                for host_port, host_port_validator in get_value_from_path(
                    port_mapping_validator,
                    port_mapping,
                    deque(["HostPort"]),
                ):
                    if not self._is_port(host_port):
                        continue
                    for container_port, _cp_validator in get_value_from_path(
                        host_port_validator,
                        port_mapping,
                        deque(["ContainerPort"]),
                    ):
                        if not self._is_port(container_port):
                            continue
                        if str(host_port) == str(container_port):
                            continue
                        yield ValidationError(
                            f"{self._format(host_port)} does not equal "
                            f"{self._format(container_port)}",
                            validator="const",
                            path_override=host_port_validator.context.path.path,
                            rule=self,
                        )

    @staticmethod
    def _is_port(value: Any) -> bool:
        return isinstance(value, (str, int)) and not isinstance(value, bool)
