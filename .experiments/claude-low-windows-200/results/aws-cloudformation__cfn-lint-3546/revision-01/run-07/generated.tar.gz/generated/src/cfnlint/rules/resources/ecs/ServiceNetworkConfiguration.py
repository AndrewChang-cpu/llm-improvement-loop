"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceNetworkConfiguration(CfnLintKeyword):
    id = "E3052"
    shortdesc = (
        "Validate ECS services using awsvpc tasks have a NetworkConfiguration"
    )
    description = (
        "When the task definition of an ECS service has a NetworkMode of 'awsvpc' "
        "the service has to specify a 'NetworkConfiguration'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _filter_resource_name(self, instance: Any) -> str | None:
        fn_k, fn_v = is_function(instance)
        if fn_k == "Ref":
            if isinstance(fn_v, str):
                return fn_v
        elif fn_k == "Fn::GetAtt":
            values = ensure_list(fn_v)
            if values and isinstance(values[0], str):
                return values[0].split(".")[0]
        return None

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[Any, Validator]]:
        for task_definition, task_definition_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._filter_resource_name(task_definition)
            if name is None:
                continue
            resource, resource_validator = get_resource_by_name(
                task_definition_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if not resource:
                continue
            yield resource, resource_validator

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        for resource, resource_validator in self._get_task_definitions(
            validator, instance
        ):
            network_modes = [
                mode
                for mode, _mode_validator in get_value_from_path(
                    resource_validator,
                    resource,
                    deque(["Properties", "NetworkMode"]),
                )
            ]
            if "awsvpc" not in network_modes:
                continue

            has_missing = any(
                network_configuration is None
                for network_configuration, _nc_validator in get_value_from_path(
                    validator, instance, deque(["NetworkConfiguration"])
                )
            )
            if has_missing:
                yield ValidationError(
                    "'NetworkConfiguration' is a required property",
                    validator="required",
                    rule=self,
                )
