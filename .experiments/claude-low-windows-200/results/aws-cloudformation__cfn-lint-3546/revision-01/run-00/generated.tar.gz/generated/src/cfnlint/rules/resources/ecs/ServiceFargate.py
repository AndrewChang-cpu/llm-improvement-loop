"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceFargate(CfnLintKeyword):
    id = "E3054"
    shortdesc = (
        "Validate ECS services using FARGATE reference task definitions "
        "that allow FARGATE"
    )
    description = (
        "When an ECS service has a 'LaunchType' of 'FARGATE' the task definition "
        "it references has to have 'RequiresCompatibilities' that includes 'FARGATE'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _get_task_definition_name(self, instance: Any) -> str | None:
        fn_k, fn_v = is_function(instance)
        if fn_k == "Ref":
            if isinstance(fn_v, str):
                return fn_v
        elif fn_k == "Fn::GetAtt":
            values = ensure_list(fn_v)
            if values and isinstance(values[0], str):
                return values[0].split(".")[0]
        return None

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[Any, Validator]]:
        for task_definition_ref, ref_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._get_task_definition_name(task_definition_ref)
            if name is None:
                continue
            task_definition, task_definition_validator = get_resource_by_name(
                ref_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if not task_definition:
                continue
            yield task_definition, task_definition_validator

    def _is_fargate_service(self, validator: Validator, instance: Any) -> bool:
        return any(
            launch_type == "FARGATE"
            for launch_type, _ in get_value_from_path(
                validator, instance, deque(["LaunchType"])
            )
        )

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        if not isinstance(instance, dict):
            return

        if not self._is_fargate_service(validator, instance):
            return

        for task_definition, task_definition_validator in self._get_task_definitions(
            validator, instance
        ):
            for properties, properties_validator in get_value_from_path(
                task_definition_validator,
                task_definition,
                deque(["Properties"]),
            ):
                for compatibilities, compatibilities_validator in get_value_from_path(
                    properties_validator,
                    properties,
                    deque(["RequiresCompatibilities"]),
                ):
                    if compatibilities is None:
                        yield ValidationError(
                            "'RequiresCompatibilities' is a required property",
                            validator="required",
                            path_override=properties_validator.context.path.path,
                            rule=self,
                        )
                        continue

                    if not isinstance(compatibilities, list):
                        continue

                    if any(
                        is_function(item)[0] is not None or item == "FARGATE"
                        for item in compatibilities
                    ):
                        continue

                    yield ValidationError(
                        f"{compatibilities!r} does not contain items "
                        "matching 'FARGATE'",
                        validator="contains",
                        path_override=compatibilities_validator.context.path.path,
                        rule=self,
                    )
