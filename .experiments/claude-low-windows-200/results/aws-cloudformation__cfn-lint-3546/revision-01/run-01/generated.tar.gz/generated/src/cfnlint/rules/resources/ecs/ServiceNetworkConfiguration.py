"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceNetworkConfiguration(CfnLintKeyword):
    id = "E3052"
    shortdesc = (
        "Validate ECS services have NetworkConfiguration when the task uses awsvpc"
    )
    description = (
        "When an ECS service references a task definition with a NetworkMode of "
        "'awsvpc' the service has to define 'NetworkConfiguration'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _resource_name(self, instance: Any) -> str | None:
        fn_k, fn_v = is_function(instance)
        if fn_k == "Ref" and isinstance(fn_v, str):
            return fn_v
        if fn_k == "Fn::GetAtt":
            items = ensure_list(fn_v)
            if items and isinstance(items[0], str):
                return items[0].split(".")[0]
        return None

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[str, Any, Validator]]:
        for task_definition, task_definition_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._resource_name(task_definition)
            if name is None:
                continue
            resource, resource_validator = get_resource_by_name(
                task_definition_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if resource is None:
                continue
            yield name, resource, resource_validator

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        seen: set[str] = set()
        for name, task_definition, task_definition_validator in (
            self._get_task_definitions(validator, instance)
        ):
            if name in seen:
                continue
            seen.add(name)

            if not self._is_awsvpc(task_definition_validator, task_definition):
                continue

            for network_configuration, _ in get_value_from_path(
                validator,
                instance,
                deque(["NetworkConfiguration"]),
            ):
                if network_configuration is None:
                    yield ValidationError(
                        "'NetworkConfiguration' is a required property",
                        validator="required",
                        rule=self,
                    )
                    break

    def _is_awsvpc(self, validator: Validator, task_definition: Any) -> bool:
        for network_mode, _ in get_value_from_path(
            validator,
            task_definition,
            deque(["Properties", "NetworkMode"]),
        ):
            if network_mode == "awsvpc":
                return True
        return False
