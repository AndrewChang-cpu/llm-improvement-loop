"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceFargate(CfnLintKeyword):
    id = "E3054"
    shortdesc = (
        "Validate ECS services using FARGATE reference task definitions that allow it"
    )
    description = (
        "When an ECS service has a LaunchType of 'FARGATE' the referenced "
        "task definition's 'RequiresCompatibilities' has to include 'FARGATE'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _resource_name(self, instance: Any) -> str | None:
        fn_k, fn_v = is_function(instance)
        if fn_k == "Ref" and isinstance(fn_v, str):
            return fn_v
        if fn_k == "Fn::GetAtt":
            items = ensure_list(fn_v)
            if items and isinstance(items[0], str):
                return items[0].split(".")[0]
        return None

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[Any, Validator]]:
        for task_definition, task_definition_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._resource_name(task_definition)
            if name is None:
                continue
            resource, resource_validator = get_resource_by_name(
                task_definition_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if resource is None:
                continue
            yield resource, resource_validator

    def _is_fargate(self, validator: Validator, instance: Any) -> bool:
        for launch_type, _ in get_value_from_path(
            validator, instance, deque(["LaunchType"])
        ):
            if launch_type == "FARGATE":
                return True
        return False

    def _format_list(self, items: list[Any]) -> str:
        formatted = []
        for item in items:
            if isinstance(item, str):
                formatted.append(f"'{item}'")
            else:
                formatted.append(str(item))
        return "[" + ", ".join(formatted) + "]"

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        if not self._is_fargate(validator, instance):
            return

        for task_definition, task_definition_validator in self._get_task_definitions(
            validator, instance
        ):
            for compatibilities, compatibilities_validator in get_value_from_path(
                task_definition_validator,
                task_definition,
                deque(["Properties", "RequiresCompatibilities"]),
            ):
                if compatibilities is None:
                    yield ValidationError(
                        "'RequiresCompatibilities' is a required property",
                        validator="required",
                        path_override=(
                            task_definition_validator.context.path.path
                            + deque(["Properties"])
                        ),
                        rule=self,
                    )
                    continue

                if not isinstance(compatibilities, list):
                    continue

                if any(
                    is_function(item)[0] is not None or item == "FARGATE"
                    for item in compatibilities
                ):
                    continue

                yield ValidationError(
                    f"{self._format_list(compatibilities)} does not contain "
                    "items matching 'FARGATE'",
                    validator="contains",
                    path_override=compatibilities_validator.context.path.path,
                    rule=self,
                )
