"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


def _get_task_definition_name(value: Any) -> str | None:
    fn_k, fn_v = is_function(value)
    if fn_k == "Ref":
        if isinstance(fn_v, str):
            return fn_v
    elif fn_k == "Fn::GetAtt":
        items = ensure_list(fn_v)
        if items and isinstance(items[0], str):
            return items[0].split(".")[0]
    return None


class ServiceNetworkConfiguration(CfnLintKeyword):
    id = "E3052"
    shortdesc = (
        "Validate ECS services have a NetworkConfiguration when the "
        "task definition uses awsvpc network mode"
    )
    description = (
        "When an ECS service references a task definition with a "
        "'NetworkMode' of 'awsvpc' the service has to specify a "
        "'NetworkConfiguration'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _is_awsvpc_task_definition(self, validator: Validator, name: str) -> bool:
        task_definition, task_definition_validator = get_resource_by_name(
            validator, name, ["AWS::ECS::TaskDefinition"]
        )
        if not task_definition:
            return False

        for network_mode, _ in get_value_from_path(
            task_definition_validator,
            task_definition,
            deque(["Properties", "NetworkMode"]),
        ):
            if network_mode == "awsvpc":
                return True
        return False

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        for task_definition, task_definition_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = _get_task_definition_name(task_definition)
            if name is None:
                continue
            if not self._is_awsvpc_task_definition(task_definition_validator, name):
                continue

            # the service may have NetworkConfiguration in some branches only
            # report once per service and task definition pair
            for network_configuration, _ in get_value_from_path(
                validator, instance, deque(["NetworkConfiguration"])
            ):
                if network_configuration is None:
                    yield ValidationError(
                        "'NetworkConfiguration' is a required property",
                        validator="required",
                        rule=self,
                    )
                    break
