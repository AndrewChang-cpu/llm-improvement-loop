"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


def _format_value(value: str | int) -> str:
    return repr(value)


class TaskDefinitionAwsVpc(CfnLintKeyword):
    id = "E3053"
    shortdesc = (
        "Validate ECS task definitions with awsvpc network mode have matching "
        "host and container ports"
    )
    description = (
        "When an ECS task definition uses 'NetworkMode' of 'awsvpc' the "
        "'HostPort' of each port mapping has to equal its 'ContainerPort'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
        )

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        for network_mode, network_mode_validator in get_value_from_path(
            validator, instance, deque(["NetworkMode"])
        ):
            if network_mode != "awsvpc":
                continue

            # keep the Properties path but apply the NetworkMode branch conditions
            branch_validator = validator.evolve(
                context=validator.context.evolve(
                    conditions=network_mode_validator.context.conditions,
                ),
            )
            for port_mapping, port_mapping_validator in get_value_from_path(
                branch_validator,
                instance,
                deque(["ContainerDefinitions", "*", "PortMappings", "*"]),
            ):
                for host_port, host_port_validator in get_value_from_path(
                    port_mapping_validator,
                    port_mapping,
                    deque(["HostPort"]),
                ):
                    if isinstance(host_port, bool) or not isinstance(
                        host_port, (str, int)
                    ):
                        continue

                    for container_port, _ in get_value_from_path(
                        host_port_validator,
                        port_mapping,
                        deque(["ContainerPort"]),
                    ):
                        if isinstance(container_port, bool) or not isinstance(
                            container_port, (str, int)
                        ):
                            continue
                        if str(host_port) == str(container_port):
                            continue

                        yield ValidationError(
                            f"{_format_value(host_port)} does not equal "
                            f"{_format_value(container_port)}",
                            validator="const",
                            path_override=host_port_validator.context.path.path,
                            rule=self,
                        )
