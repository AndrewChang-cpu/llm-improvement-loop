"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceFargate(CfnLintKeyword):
    id = "E3054"
    shortdesc = (
        "Validate ECS services using FARGATE reference task definitions "
        "that allow FARGATE"
    )
    description = (
        "When an ECS service has a LaunchType of 'FARGATE' the referenced "
        "task definition must have 'RequiresCompatibilities' that includes 'FARGATE'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _filter_resource_name(self, instance: Any) -> str | None:
        fn_k, fn_v = is_function(instance)
        if fn_k is None:
            return None
        if fn_k == "Ref":
            if isinstance(fn_v, str):
                return fn_v
        elif fn_k == "Fn::GetAtt":
            names = ensure_list(fn_v)
            if names and isinstance(names[0], str):
                return names[0].split(".")[0]
        return None

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[Any, Validator]]:
        for task_definition_ref, ref_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._filter_resource_name(task_definition_ref)
            if name is None:
                continue
            task_definition, task_definition_validator = get_resource_by_name(
                ref_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if not task_definition:
                continue
            yield task_definition, task_definition_validator

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        is_fargate = False
        for launch_type, _launch_validator in get_value_from_path(
            validator, instance, deque(["LaunchType"])
        ):
            if launch_type == "FARGATE":
                is_fargate = True
        if not is_fargate:
            return

        for task_definition, task_definition_validator in self._get_task_definitions(
            validator, instance
        ):
            for properties, properties_validator in get_value_from_path(
                task_definition_validator, task_definition, deque(["Properties"])
            ):
                for compatibilities, compat_validator in get_value_from_path(
                    properties_validator,
                    properties,
                    deque(["RequiresCompatibilities"]),
                ):
                    if compatibilities is None:
                        yield ValidationError(
                            "'RequiresCompatibilities' is a required property",
                            validator="required",
                            rule=self,
                            path_override=properties_validator.context.path.path,
                        )
                        continue

                    if not isinstance(compatibilities, list):
                        continue

                    if any(
                        is_function(item)[0] is not None or item == "FARGATE"
                        for item in compatibilities
                    ):
                        continue

                    yield ValidationError(
                        f"{compatibilities!r} does not contain items matching "
                        "'FARGATE'",
                        validator="contains",
                        rule=self,
                        path_override=compat_validator.context.path.path,
                    )
