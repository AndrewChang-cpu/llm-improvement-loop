"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class TaskDefinitionAwsVpc(CfnLintKeyword):
    id = "E3053"
    shortdesc = (
        "Validate ECS awsvpc port mappings have matching host and container ports"
    )
    description = (
        "When an ECS task definition uses NetworkMode 'awsvpc' the HostPort "
        "of each port mapping must equal its ContainerPort"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
        )

    def _get_port_mappings(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[Any, Any, Validator]]:
        for container, container_validator in get_value_from_path(
            validator, instance, deque(["ContainerDefinitions", "*"])
        ):
            for port_mapping, port_mapping_validator in get_value_from_path(
                container_validator, container, deque(["PortMappings", "*"])
            ):
                for host_port, host_port_validator in get_value_from_path(
                    port_mapping_validator, port_mapping, deque(["HostPort"])
                ):
                    if host_port is None or not isinstance(host_port, (str, int)):
                        continue
                    for container_port, _ in get_value_from_path(
                        port_mapping_validator,
                        port_mapping,
                        deque(["ContainerPort"]),
                    ):
                        if container_port is None or not isinstance(
                            container_port, (str, int)
                        ):
                            continue
                        yield host_port, container_port, host_port_validator

    @staticmethod
    def _display(value: str | int) -> str:
        return repr(value)

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        is_awsvpc = False
        for network_mode, _mode_validator in get_value_from_path(
            validator, instance, deque(["NetworkMode"])
        ):
            if network_mode == "awsvpc":
                is_awsvpc = True
        if not is_awsvpc:
            return

        for host_port, container_port, host_port_validator in self._get_port_mappings(
            validator, instance
        ):
            if str(host_port) == str(container_port):
                continue
            yield ValidationError(
                f"{self._display(host_port)} does not equal "
                f"{self._display(container_port)}",
                validator="const",
                rule=self,
                path_override=host_port_validator.context.path.path,
            )
