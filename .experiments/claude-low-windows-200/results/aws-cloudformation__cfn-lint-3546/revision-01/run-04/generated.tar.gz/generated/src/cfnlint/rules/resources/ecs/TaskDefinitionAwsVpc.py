"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class TaskDefinitionAwsVpc(CfnLintKeyword):
    id = "E3053"
    shortdesc = (
        "Validate ECS task definitions using awsvpc network mode have "
        "matching host and container ports"
    )
    description = (
        "When the ECS task definition has a NetworkMode of 'awsvpc' "
        "the 'HostPort' of each port mapping has to equal its 'ContainerPort'"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ecs-taskdefinition-portmapping.html"
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
        )

    def _is_valid_port(self, value: Any) -> bool:
        return isinstance(value, (str, int)) and not isinstance(value, bool)

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        is_awsvpc = False
        for network_mode, _mode_validator in get_value_from_path(
            validator, instance, deque(["NetworkMode"])
        ):
            if network_mode == "awsvpc":
                is_awsvpc = True
        if not is_awsvpc:
            return

        for container, container_validator in get_value_from_path(
            validator, instance, deque(["ContainerDefinitions", "*"])
        ):
            for mapping, mapping_validator in get_value_from_path(
                container_validator, container, deque(["PortMappings", "*"])
            ):
                for host, host_validator in get_value_from_path(
                    mapping_validator, mapping, deque(["HostPort"])
                ):
                    if not self._is_valid_port(host):
                        continue
                    for container_port, _port_validator in get_value_from_path(
                        mapping_validator, mapping, deque(["ContainerPort"])
                    ):
                        if not self._is_valid_port(container_port):
                            continue
                        if str(host) == str(container_port):
                            continue
                        yield ValidationError(
                            f"{host!r} does not equal {container_port!r}",
                            validator="const",
                            rule=self,
                            path_override=host_validator.context.path.path,
                        )
