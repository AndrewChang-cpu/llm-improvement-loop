"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class ServiceFargate(CfnLintKeyword):
    id = "E3054"
    shortdesc = (
        "Validate ECS services using FARGATE reference task definitions "
        "that are compatible with FARGATE"
    )
    description = (
        "When the ECS service has a LaunchType of 'FARGATE' the referenced "
        "task definition has to include 'FARGATE' in its 'RequiresCompatibilities'"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-taskdefinition.html#cfn-ecs-taskdefinition-requirescompatibilities"
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _filter_resource_name(self, instance: Any) -> str | None:
        fn_k, fn_v = is_function(instance)
        if fn_k == "Ref" and isinstance(fn_v, str):
            return fn_v
        if fn_k == "Fn::GetAtt":
            items = ensure_list(fn_v)
            if items and isinstance(items[0], str):
                return items[0].split(".")[0]
        return None

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[Any, Validator]]:
        for task_definition_ref, ref_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = self._filter_resource_name(task_definition_ref)
            if name is None:
                continue
            task_definition, task_definition_validator = get_resource_by_name(
                ref_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if not task_definition:
                continue
            yield task_definition, task_definition_validator

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        is_fargate = False
        for launch_type, _launch_validator in get_value_from_path(
            validator, instance, deque(["LaunchType"])
        ):
            if launch_type == "FARGATE":
                is_fargate = True
        if not is_fargate:
            return

        for task_definition, task_definition_validator in self._get_task_definitions(
            validator, instance
        ):
            for properties, properties_validator in get_value_from_path(
                task_definition_validator, task_definition, deque(["Properties"])
            ):
                for compat, compat_validator in get_value_from_path(
                    properties_validator,
                    properties,
                    deque(["RequiresCompatibilities"]),
                ):
                    if compat is None:
                        yield ValidationError(
                            "'RequiresCompatibilities' is a required property",
                            validator="required",
                            rule=self,
                            path_override=properties_validator.context.path.path,
                        )
                        continue
                    if is_function(compat)[0] is not None:
                        continue
                    if not isinstance(compat, list):
                        continue
                    if any(
                        is_function(item)[0] is not None or item == "FARGATE"
                        for item in compat
                    ):
                        continue
                    yield ValidationError(
                        f"{compat!r} does not contain items matching 'FARGATE'",
                        validator="contains",
                        rule=self,
                        path_override=compat_validator.context.path.path,
                    )
