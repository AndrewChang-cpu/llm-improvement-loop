"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from cfnlint.helpers import ensure_list, is_function
from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_resource_by_name, get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


def _get_reference_name(value: Any) -> str | None:
    fn_k, fn_v = is_function(value)
    if fn_k == "Ref":
        if isinstance(fn_v, str):
            return fn_v
    elif fn_k == "Fn::GetAtt":
        values = ensure_list(fn_v)
        if values and isinstance(values[0], str):
            return values[0].split(".")[0]
    return None


def _format_value(value: Any) -> str:
    if isinstance(value, str):
        return f"'{value}'"
    return str(value)


class ServiceFargate(CfnLintKeyword):
    id = "E3054"
    shortdesc = "Validate ECS services using FARGATE reference FARGATE task definitions"
    description = (
        "When an ECS service uses the 'FARGATE' launch type the task definition "
        "it references must have 'FARGATE' in its 'RequiresCompatibilities'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
        )

    def _get_task_definitions(
        self, validator: Validator, instance: Any
    ) -> Iterator[tuple[str, Any, Validator]]:
        for task_ref, task_ref_validator in get_value_from_path(
            validator, instance, deque(["TaskDefinition"])
        ):
            name = _get_reference_name(task_ref)
            if name is None:
                continue
            task_def, task_def_validator = get_resource_by_name(
                task_ref_validator, name, ["AWS::ECS::TaskDefinition"]
            )
            if not task_def:
                continue
            yield name, task_def, task_def_validator

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        launch_types = [
            launch_type
            for launch_type, _ in get_value_from_path(
                validator, instance, deque(["LaunchType"])
            )
        ]
        if "FARGATE" not in launch_types:
            return

        for name, task_def, task_def_validator in self._get_task_definitions(
            validator, instance
        ):
            for requires, requires_validator in get_value_from_path(
                task_def_validator,
                task_def,
                deque(["Properties", "RequiresCompatibilities"]),
            ):
                if requires is None:
                    yield ValidationError(
                        "'RequiresCompatibilities' is a required property",
                        validator="required",
                        path_override=deque(["Resources", name, "Properties"]),
                        rule=self,
                    )
                    continue

                if not isinstance(requires, list):
                    continue

                if any(
                    is_function(item)[0] is not None or item == "FARGATE"
                    for item in requires
                ):
                    continue

                items = ", ".join(_format_value(item) for item in requires)
                yield ValidationError(
                    f"[{items}] does not contain items matching 'FARGATE'",
                    validator="contains",
                    path_override=requires_validator.context.path.path,
                    rule=self,
                )
