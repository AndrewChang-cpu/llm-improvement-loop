"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


def _format_port(value: Any) -> str:
    if isinstance(value, str):
        return f"'{value}'"
    return str(value)


def _is_port(value: Any) -> bool:
    return isinstance(value, (str, int)) and not isinstance(value, bool)


class TaskDefinitionAwsVpc(CfnLintKeyword):
    id = "E3053"
    shortdesc = (
        "Validate ECS awsvpc task definitions have matching host and container ports"
    )
    description = (
        "When an ECS task definition uses the 'awsvpc' network mode the "
        "'HostPort' of each port mapping must equal its 'ContainerPort'"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
        )

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        modes = [
            mode
            for mode, _ in get_value_from_path(
                validator, instance, deque(["NetworkMode"])
            )
        ]
        if "awsvpc" not in modes:
            return

        for container, container_validator in get_value_from_path(
            validator, instance, deque(["ContainerDefinitions", "*"])
        ):
            for mapping, mapping_validator in get_value_from_path(
                container_validator, container, deque(["PortMappings", "*"])
            ):
                container_ports = [
                    port
                    for port, _ in get_value_from_path(
                        mapping_validator, mapping, deque(["ContainerPort"])
                    )
                ]
                for host_port, host_port_validator in get_value_from_path(
                    mapping_validator, mapping, deque(["HostPort"])
                ):
                    for container_port in container_ports:
                        if not _is_port(host_port) or not _is_port(container_port):
                            continue
                        if str(host_port) == str(container_port):
                            continue
                        yield ValidationError(
                            f"{_format_port(host_port)} does not equal "
                            f"{_format_port(container_port)}",
                            validator="const",
                            path_override=host_port_validator.context.path.path,
                            rule=self,
                        )
