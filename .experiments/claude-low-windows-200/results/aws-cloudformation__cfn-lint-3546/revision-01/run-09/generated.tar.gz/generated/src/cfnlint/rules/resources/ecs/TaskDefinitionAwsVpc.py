"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from collections import deque
from typing import Any

from cfnlint.jsonschema import ValidationError, ValidationResult
from cfnlint.jsonschema.protocols import Validator
from cfnlint.rules.helpers import get_value_from_path
from cfnlint.rules.jsonschema.CfnLintKeyword import CfnLintKeyword


class TaskDefinitionAwsVpc(CfnLintKeyword):
    id = "E3053"
    shortdesc = (
        "Validate ECS awsvpc task port mappings have matching host and container ports"
    )
    description = (
        "When an ECS task definition has a NetworkMode of 'awsvpc' "
        "the HostPort of each port mapping has to equal its ContainerPort"
    )
    tags = ["resources", "ecs"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
        )

    def validate(
        self, validator: Validator, _: Any, instance: Any, schema: dict[str, Any]
    ) -> ValidationResult:
        network_modes = [
            mode
            for mode, _ in get_value_from_path(
                validator, instance, deque(["NetworkMode"])
            )
        ]
        if "awsvpc" not in network_modes:
            return

        for container, container_validator in get_value_from_path(
            validator, instance, deque(["ContainerDefinitions", "*"])
        ):
            for port_mapping, port_mapping_validator in get_value_from_path(
                container_validator,
                container,
                deque(["PortMappings", "*"]),
            ):
                host_ports = list(
                    get_value_from_path(
                        port_mapping_validator, port_mapping, deque(["HostPort"])
                    )
                )
                container_ports = list(
                    get_value_from_path(
                        port_mapping_validator, port_mapping, deque(["ContainerPort"])
                    )
                )
                for host_port, host_port_validator in host_ports:
                    if not isinstance(host_port, (str, int)):
                        continue
                    for container_port, _ in container_ports:
                        if not isinstance(container_port, (str, int)):
                            continue
                        if str(host_port) == str(container_port):
                            continue
                        yield ValidationError(
                            f"{host_port!r} does not equal {container_port!r}",
                            validator="const",
                            path_override=host_port_validator.context.path.path,
                            rule=self,
                        )
