"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_taskdefinition
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class FargateNetworkMode(CfnLintJsonSchema):
    id = "E3052"
    shortdesc = "Validate ECS Fargate task definitions use the awsvpc network mode"
    description = (
        "When using a ECS task definition with FARGATE compatibility "
        "the NetworkMode has to be 'awsvpc'"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-taskdefinition.html#cfn-ecs-taskdefinition-networkmode"
    tags = ["properties", "ecs", "task", "fargate", "network"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_taskdefinition,
                filename="fargate_network_mode.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return err.message
