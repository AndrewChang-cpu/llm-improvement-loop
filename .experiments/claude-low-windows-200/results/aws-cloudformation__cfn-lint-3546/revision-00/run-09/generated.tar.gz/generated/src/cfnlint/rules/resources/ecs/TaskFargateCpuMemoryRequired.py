"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_taskdefinition
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class TaskFargateCpuMemoryRequired(CfnLintJsonSchema):
    id = "E3054"
    shortdesc = "Validate ECS Fargate tasks specify task level Cpu and Memory"
    description = (
        "When using a ECS task definition with 'FARGATE' in 'RequiresCompatibilities' "
        "the task level 'Cpu' and 'Memory' are required"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-taskdefinition.html#cfn-ecs-taskdefinition-cpu"
    tags = ["properties", "ecs", "task", "fargate"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_taskdefinition,
                filename="fargate_cpu_memory_required.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return err.message
