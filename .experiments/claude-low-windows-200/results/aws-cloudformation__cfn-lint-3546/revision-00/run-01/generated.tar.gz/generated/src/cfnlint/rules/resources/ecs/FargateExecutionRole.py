"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_taskdefinition
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class FargateExecutionRole(CfnLintJsonSchema):
    id = "E3054"
    shortdesc = "Validate ECS Fargate task definitions have an ExecutionRoleArn"
    description = (
        "When using a ECS task definition with RequiresCompatibilities of FARGATE the ExecutionRoleArn is required"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-taskdefinition.html#cfn-ecs-taskdefinition-executionrolearn"
    tags = ["properties", "ecs", "fargate"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_taskdefinition,
                filename="fargate_execution_role.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return "ECS Fargate task definitions require an ExecutionRoleArn"
