"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_service
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class ServiceHealthCheckGracePeriod(CfnLintJsonSchema):
    id = "E3054"
    shortdesc = (
        "Validate ECS services with HealthCheckGracePeriodSeconds have load balancers"
    )
    description = (
        "When an ECS service specifies 'HealthCheckGracePeriodSeconds' "
        "at least one 'LoadBalancers' entry is required"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-service.html#cfn-ecs-service-healthcheckgraceperiodseconds"
    tags = ["properties", "ecs", "service", "load_balancer"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_service,
                filename="health_check_grace_period.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return (
            "'LoadBalancers' with at least one entry is required "
            "when 'HealthCheckGracePeriodSeconds' is specified"
        )
