"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_service
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class FargateServiceNetworkConfiguration(CfnLintJsonSchema):
    id = "E3053"
    shortdesc = "Validate ECS Fargate services have an AwsvpcConfiguration"
    description = (
        "When an ECS service uses the FARGATE launch type "
        "the NetworkConfiguration with an AwsvpcConfiguration is required"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-service.html#cfn-ecs-service-networkconfiguration"
    tags = ["properties", "ecs", "service", "fargate", "network"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_service,
                filename="fargate_network_configuration.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return (
            "'NetworkConfiguration' with 'AwsvpcConfiguration' is required "
            "for FARGATE services"
        )
