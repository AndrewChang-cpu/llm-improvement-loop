"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_taskdefinition
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class TaskFargatePrivileged(CfnLintJsonSchema):
    id = "E3053"
    shortdesc = "Validate ECS Fargate tasks don't use privileged containers"
    description = (
        "When 'RequiresCompatibilities' includes 'FARGATE' no container definition "
        "can set 'Privileged' to true"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ecs-taskdefinition-containerdefinition.html#cfn-ecs-taskdefinition-containerdefinition-privileged"
    tags = ["properties", "ecs", "task", "container", "fargate"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_taskdefinition,
                filename="fargate_privileged.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return "Fargate tasks don't support privileged containers"
