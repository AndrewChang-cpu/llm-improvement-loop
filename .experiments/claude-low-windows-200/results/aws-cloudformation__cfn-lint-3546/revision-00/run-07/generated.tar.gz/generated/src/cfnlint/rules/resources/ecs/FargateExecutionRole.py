"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_taskdefinition
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class FargateExecutionRole(CfnLintJsonSchema):
    id = "E3053"
    shortdesc = (
        "Validate ECS Fargate task definitions using awslogs have an ExecutionRoleArn"
    )
    description = (
        "When a task definition is compatible with FARGATE and a container uses the "
        "'awslogs' log driver the ExecutionRoleArn is required"
    )
    source_url = "https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task_definition_parameters.html#exec-role"
    tags = ["properties", "ecs", "task", "fargate", "container", "logging"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_taskdefinition,
                filename="fargate_execution_role.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return err.message
