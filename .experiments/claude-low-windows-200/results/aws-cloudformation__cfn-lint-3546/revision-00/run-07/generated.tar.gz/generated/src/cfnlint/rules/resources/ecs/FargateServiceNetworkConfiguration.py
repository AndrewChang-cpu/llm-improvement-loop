"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_service
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class FargateServiceNetworkConfiguration(CfnLintJsonSchema):
    id = "E3054"
    shortdesc = "Validate ECS services using FARGATE have a NetworkConfiguration"
    description = (
        "When using a LaunchType of FARGATE the NetworkConfiguration is required"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-service.html#cfn-ecs-service-networkconfiguration"
    tags = ["properties", "ecs", "service", "fargate", "network"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::Service/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_service,
                filename="fargate_network_configuration.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return err.message
