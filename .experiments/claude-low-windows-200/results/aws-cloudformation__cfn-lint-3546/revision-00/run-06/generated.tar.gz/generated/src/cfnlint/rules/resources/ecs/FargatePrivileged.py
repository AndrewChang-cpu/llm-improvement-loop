"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
"""

from __future__ import annotations

from typing import Any

import cfnlint.data.schemas.extensions.aws_ecs_taskdefinition
from cfnlint.jsonschema import ValidationError
from cfnlint.rules.jsonschema.CfnLintJsonSchema import CfnLintJsonSchema, SchemaDetails


class FargatePrivileged(CfnLintJsonSchema):
    id = "E3054"
    shortdesc = "Validate ECS Fargate tasks do not use privileged containers"
    description = (
        "When a task definition requires FARGATE compatibility "
        "no container definition can set 'Privileged' to true"
    )
    source_url = "https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ecs-taskdefinition-containerdefinitions.html#cfn-ecs-taskdefinition-containerdefinition-privileged"
    tags = ["properties", "ecs", "task", "container", "fargate"]

    def __init__(self) -> None:
        super().__init__(
            keywords=["Resources/AWS::ECS::TaskDefinition/Properties"],
            schema_details=SchemaDetails(
                module=cfnlint.data.schemas.extensions.aws_ecs_taskdefinition,
                filename="fargate_privileged.json",
            ),
        )

    def message(self, instance: Any, err: ValidationError) -> str:
        return "'Privileged' isn't supported for ECS Fargate tasks"
